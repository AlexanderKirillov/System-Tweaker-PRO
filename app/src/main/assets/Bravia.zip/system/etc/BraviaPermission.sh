#!/sbin/sh

# Bravia Engine * X-reality * SuperVivid
busybox chown 0.0 /system/bin/be_movie
busybox chown 0.0 /system/bin/be_movie_spc
busybox chmod 0755 /system/bin/be_movie
busybox chmod 0755 /system/bin/be_movie_spc
# Bravia Engine * X-reality * SuperVivid
busybox chown 0.0 /system/etc/be_album
busybox chown 0.0 /system/etc/be_photo
busybox chown 0.0 /system/etc/be_movie
busybox chown 0.0 /system/etc/be_movie_setting
busybox chown 0.0 /system/etc/be_movie_spc
busybox chown 0.0 /system/etc/be2_album
busybox chown 0.0 /system/etc/be2_album01
busybox chown 0.0 /system/etc/be2_album02
busybox chown 0.0 /system/etc/be2_album_mapping
# Bravia Engine * X-reality * SuperVivid
busybox chmod 0755 /system/etc/be_album
busybox chmod 0755 /system/etc/be_photo
busybox chmod 0755 /system/etc/be_movie
busybox chmod 0755 /system/etc/be_movie_setting
busybox chmod 0755 /system/etc/be_movie_spc
busybox chmod 0755 /system/etc/be2_album
busybox chmod 0755 /system/etc/be2_album01
busybox chmod 0755 /system/etc/be2_album02
busybox chmod 0755 /system/etc/be2_album_mapping
#
# Plamb1r@XDA
#
