#!/sbin/sh

# X-reality * SuperVivid
busybox chown 0.0 /system/bin/sony_z3_imageenhancer
busybox chown 0.0 /system/bin/sony_z5_imageenhancer
busybox chmod 0755 /system/bin/sony_z3_imageenhancer
busybox chmod 0755 /system/bin/sony_z5_imageenhancer
# X-reality * SuperVivid
busybox chown 0.0 /system/etc/be_movie_spc
busybox chown 0.0 /system/etc/be2_album
busybox chown 0.0 /system/etc/be2_album01
busybox chown 0.0 /system/etc/be2_album02
busybox chown 0.0 /system/etc/be2_album_mapping
# X-reality * SuperVivid
busybox chmod 0755 /system/etc/be_movie_spc
busybox chmod 0755 /system/etc/be2_album
busybox chmod 0755 /system/etc/be2_album01
busybox chmod 0755 /system/etc/be2_album02
busybox chmod 0755 /system/etc/be2_album_mapping
#
# Plamb1r
@XDA
#
